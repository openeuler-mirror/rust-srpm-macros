from .metadata import *
from . import licensing

__version__ = '21'
